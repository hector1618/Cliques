#! usr/bin/python

#This file will be used as main file which contains all the functions

import all_maximal_cliques
#import coloring.py
#import is_clique_k.py
#import max_clique.py
#import random_graph.py
