#!/usr/bin/env python
# I have no idea what is this first line is for.

from distutils.core import setup


setup(name = 'Cliques',
      version = '1.0',
      description = 'For finding the cliques in undirected graphs',
      auther= 'Hector',
      auther_email= 'hector1618@gmail.com',
      py_modules = ['cliques'], 
)
